package com.capgemini.musicplayer.songs;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Properties;
import java.util.Scanner;

public class AddSong {

	void addSongs() {
		
		try(Scanner scanner = new Scanner(System.in);
				FileInputStream  stream = new FileInputStream("assessment.properties")) {
			Properties properties = new Properties();
			properties.load(stream);
			
			try {
				Class.forName(properties.getProperty("driver_name"));
			} catch (Exception e1) {
				e1.printStackTrace();
			}
			
			String url = properties.getProperty("url");
			String sql = "Insert into MusicFiles values(?,?,?,?,?,?)";
			
			try(Connection connection = DriverManager.getConnection(url,properties);
					PreparedStatement preparedStatement = connection.prepareStatement(sql)) {
				
				System.out.println("Enter the Song Detailes");
				System.out.println("-----------------------------------");
				
				System.out.println("Song_ID");
				int song_id = scanner.nextInt();
				
				System.out.println("Song_Title");
				String song_title = scanner.next();
				
				System.out.println("Artist_Name");
				String artist_name = scanner.next();
				
				System.out.println("Album_Name");
				String album_name = scanner.next();
				
				System.out.println("Song_Location");
				String song_location = scanner.next();
				
				System.out.println("Description");
				String description = scanner.next();
				
				preparedStatement.setInt(1, song_id);
				preparedStatement.setString(2, song_title);
				preparedStatement.setString(3, artist_name);
				preparedStatement.setString(4, album_name);
				preparedStatement.setString(5, song_location);
				preparedStatement.setString(6, description);
				
				int count = preparedStatement.executeUpdate();
				
				System.out.println(count +" rows affected");
			} catch (SQLException e) {
				e.printStackTrace();
			}
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
}
