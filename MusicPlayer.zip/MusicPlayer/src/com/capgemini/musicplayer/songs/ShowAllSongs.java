package com.capgemini.musicplayer.songs;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Properties;


public class ShowAllSongs {

	void showSongs() {

		try(FileInputStream stream = new FileInputStream("assessment.properties")) {
			Properties properties = new Properties();

			properties.load(stream);

			String url = properties.getProperty("url");
			String sql = "Select * from MusicFiles order by Song_Title";

			Class.forName(properties.getProperty("driver_name"));

			try(Connection connection = DriverManager.getConnection(url,properties);
					PreparedStatement preparedStatement = connection.prepareStatement(sql);
					ResultSet resultSet = preparedStatement.executeQuery()) {
				System.out.println("Song_ID\t Song_Title\t Artist_Name\t Album_Name\t Song_Location\t Description");
				while(resultSet.next()) {
					System.out.print(resultSet.getInt("Song_ID")+"\t\t");
					System.out.print(resultSet.getString("Song_Title")+"\t\t ");
					System.out.print(resultSet.getString("Artist_Name")+"\t\t ");
					System.out.print(resultSet.getString("Album_Name")+"\t\t ");
					System.out.print(resultSet.getString("Song_Location")+"\t\t ");
					System.out.print(resultSet.getString("Description")+"\t\t ");
					System.out.println();
				}
			} catch (SQLException e) {
				e.printStackTrace();
			}
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
	}
}
