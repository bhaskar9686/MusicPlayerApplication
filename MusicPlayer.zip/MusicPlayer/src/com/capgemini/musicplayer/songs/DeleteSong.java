package com.capgemini.musicplayer.songs;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Properties;
import java.util.Scanner;

public class DeleteSong {

	void deleteSong() {

		try(Scanner scanner = new Scanner(System.in);
				FileInputStream stream = new FileInputStream("assessment.properties")) {
			Properties properties = new Properties();
			properties.load(stream);

			String url = properties.getProperty("url");
			String sql = "Delete from MusicFiles where Song_ID = ?";

			Class.forName(properties.getProperty("driver_name"));

			try(Connection connection = DriverManager.getConnection(url,properties);
					PreparedStatement preparedStatement = connection.prepareStatement(sql)) {

				System.out.println("Enter the Song_Id to delete the song");
				int song_id = scanner.nextInt();

				preparedStatement.setInt(1, song_id);

				int count = preparedStatement.executeUpdate();
				System.out.println(count+" rows affected");
			} catch (SQLException e) {
				e.printStackTrace();
			}
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
	}
}
