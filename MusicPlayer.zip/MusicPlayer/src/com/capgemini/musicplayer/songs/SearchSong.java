package com.capgemini.musicplayer.songs;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Properties;

public class SearchSong {
	void searchBySong(String song_title) {
		
		try(FileInputStream stream = new FileInputStream("assessment.properties")) {
			Properties properties = new Properties();
			properties.load(stream);
			
			String url = properties.getProperty("url");
			String sql = "Select * from MusicFiles where Song_Title = ?";
			
			Class.forName(properties.getProperty("driver_name"));
			
			try(Connection connection = DriverManager.getConnection(url,properties);
					PreparedStatement preparedStatement = connection.prepareStatement(sql)) {
				preparedStatement.setString(1, song_title);
				System.out.println("Title \t Artist \t Album");
				System.out.println("------------------------------------------");
				try(ResultSet resultSet = preparedStatement.executeQuery()) {
					while(resultSet.next()) {
						System.out.print(resultSet.getString("Song_Title")+"\t");
						System.out.print(resultSet.getString("Artist_Name")+" \t");
						System.out.print(resultSet.getString("Album_Name")+" \t");
					}
				} catch (SQLException e) {
					e.printStackTrace();
				}
			} catch (SQLException e1) {
				e1.printStackTrace();
			}
		} catch (ClassNotFoundException e2) {
			e2.printStackTrace();
		} catch (FileNotFoundException e3) {
			e3.printStackTrace();
		} catch (IOException e3) {
			e3.printStackTrace();
		}
	}

}
