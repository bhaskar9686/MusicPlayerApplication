package com.capgemini.musicplayer.songs;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Properties;

public class PlayAllSongs {

	void playAllSongs() {
		
		String sql = "Select * from MusicFiles order by Song_Title";
		try(FileInputStream stream = new FileInputStream("assessment.properties")) {
			Properties properties = new Properties();
			properties.load(stream);
			
			String url = properties.getProperty("url");
			Class.forName(properties.getProperty("driver_name"));
			
			try(Connection connection = DriverManager.getConnection(url, properties);
					PreparedStatement preparedStatement = connection.prepareStatement(sql);
					ResultSet resultSet = preparedStatement.executeQuery()) {
				
				while(resultSet.next()) {
					System.out.println("playing :"+ resultSet.getString("Song_Title") +" Song");
					try {
						Thread.sleep(4000);
					} catch (InterruptedException e) {
						e.printStackTrace();
					}
				}
				
			} catch (SQLException e) {
				e.printStackTrace();
			}
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
	}
}
