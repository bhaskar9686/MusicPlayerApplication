package com.capgemini.musicplayer.songs;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Properties;
import java.util.Scanner;

public class EditSong {

	void editSong() {
		
		try(Scanner scanner = new Scanner(System.in);
				FileInputStream stream = new  FileInputStream("assessment.properties")) {
			Properties properties = new Properties();
			
			properties.load(stream);
			
			String url = properties.getProperty("url");
			String sql = "Update MusicFiles set Song_Title = ?,Artist_Name = ? where Song_ID= ?";
			
			Class.forName(properties.getProperty("driver_name"));
			
			try(Connection connection = DriverManager.getConnection(url,properties);
					PreparedStatement preparedStatement = connection.prepareStatement(sql)) {
				
				System.out.println("Enter the Song_ID to be Edited");
				int song_id = scanner.nextInt();
			
				System.out.println("Enter the new Song_Title");
				String song_title = scanner.next();
				
				System.out.println("Enter the new Artist_Name");
				String artist_name = scanner.next();
				
				preparedStatement.setString(1, song_title);
				preparedStatement.setString(2, artist_name);
				preparedStatement.setInt(3, song_id);
				
				int count = preparedStatement.executeUpdate();
				
				System.out.println(count + " row affected");
			} catch (SQLException e) {
				e.printStackTrace();
			}
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
	}
}
